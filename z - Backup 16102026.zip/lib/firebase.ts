import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth"; // <-- Adicionado
import { initializeFirestore, memoryLocalCache } from "firebase/firestore";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Exporta o Auth para usar no Login
export const auth = getAuth(app); // <-- Adicionado

// Desativa conexões de stream/webchannel e força o transporte por requisições HTTP Fetch puras
export const db = initializeFirestore(app, {
  experimentalAutoDetectLongPolling: false,
  experimentalForceLongPolling: true,
  localCache: memoryLocalCache(),
});